//
//  PersonViewModel.swift
//  Curious-Katie
//
//  Created by Ahmed Chishti on 12/11/20.


import Foundation

// Used struct instead of class because copying is much safer than having multiple references to the same instance as happens with classes.

struct Katie {
    
    private var persons : [[String]]
    private var interests: [String:[String]]
    private var sharedInterests: [String: [Person]] = [:]
    private var participants = [Person]()
    
    init() {
        self.persons = getData()
        self.interests = getInterests()
    }
    // Sends data to console
    
    func sendData() -> [[String]] {
        
        return persons
        
    }
    
    // Gets participants, makes sure that at minimum 2 participants are used and at max 12 participants are used.
    
    mutating func getParticipants() {
        let cutoff = (2...12).randomElement() ?? 12
        var count = 0
        for participant in persons {
            if count < cutoff {
                defer { count += 1 }
                let thisParticipant = Person(name: participant[0], hometown: participant[1], age: participant[2], interest: interests[participant[0]]!)
                participants.append(thisParticipant)
            } else {
                break
            }
            
        }
    }
    // Katie asks for introduction
    
    func introduceGuys() {
        print("Katie: Please introduce yourselves...\n")
        for guy in participants {
            guy.introduceSelf()
        }
    }
    
    // Iterates through the interests until all participants have been used
    
    mutating func iterateInterests() {
        while !participants.isEmpty {
            participants.shuffle()
            let person = participants[0]
            
            if person.interest.isEmpty {
                participants.remove(at: 0)
                continue
            }
            
            print("Katie: \(person.name), tell me an interest of yours.\n")
            
            let interest = participants[0].shareInterest()
            
            
            defer {
                sharedInterests[interest]?.append(person)
            }
            if sharedInterests[interest] == nil {
                sharedInterests[interest] = []
            }
        }
        print("Katie: Thank you for sharing your interests.\n")
    }
    
    // Pairs up the participants and interests
    
    func pairInterests() {
        for (interest, group) in sharedInterests {
            var group = group
            while group.count > 2 { group.removeLast() }
            if group.count == 2 {
                print("Katie: \(group.removeFirst().name) please gather with \(group.removeLast().name) and discuss \(interest).\n")
            }
        }
    }
    
    // Katie says thanks for participating
    
    func sayThanks() {
        print("Katie: Thank you all for participating.", "\n")
        
        // Gets interests for each person from the data model
        
        func getPersonInterests(name: String) -> [String]? {
            if let interest = interests[name] {
                return interest
            }
            
            return nil
            
        }
        
        // Gets participant names from the data model
        
        func getParticipantNames() -> [String] {
            var names = [String]()
            
            for participant in participants {
                
                names.append(participant.name)
                
            }
            
            return names
        }
    }
}
