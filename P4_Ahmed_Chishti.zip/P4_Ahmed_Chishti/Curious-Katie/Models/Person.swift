//
//  Person.swift
//  Curious-Katie
//
//  Created by Ahmed Chishti on 12/10/20.
//

import Foundation

struct Person: Equatable {
    var name: String
    var hometown: String
    var age: String
    var interest: [String]
    
    init(name: String, hometown: String, age: String, interest: [String]) {
        self.name = name
        self.hometown = hometown
        self.age = age
        self.interest = interest
    }
    // Introduces participants
    func introduceSelf() {
        print("Hi, my name is \(name), I'm \(age) and I grew up in \(hometown).", "\n")
    }
    // Randomizes interests
    mutating func shareInterest() -> String {
        
        interest.shuffle()
        let randomInterest = interest.removeFirst()
        print("\(name): I like \(randomInterest).", "\n")
        return randomInterest
    }
}

