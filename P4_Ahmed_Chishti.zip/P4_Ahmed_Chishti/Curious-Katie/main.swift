//
//  main.swift
//  Curious-Katie
//
//  Created by Ahmed Chishti on 12/8/20.
//

import Foundation

// This instantiates Katie
var katie = Katie() // The view knows about the view model, the view does not know about the model itself.

katie.getParticipants()
katie.introduceGuys()
katie.iterateInterests()
katie.pairInterests()
katie.sayThanks()

