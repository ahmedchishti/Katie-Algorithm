# KatieAlgorithm

This algorithm was created for my 4th project, "Implement your first algorithm in Swift!" on OpenClassrooms.

The algorithm deals with 2-12 participants. Participants introduce themselves one by one. After all the participants have introduced themselves, "Katie" then randomly nominate a participants and compares their interests, any differences will then be listed in the debug panel. Each person has a variety of interests, all with a short description and information about the interests.

© Ahmed Chishti

email: ahmedchishti2k@gmail.com

github link for this project: https://github.com/ahmedchishti/KatieAlgorithm.git
